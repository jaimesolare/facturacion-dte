# Guía de Despliegue a Producción

Esta guía detalla los pasos para desplegar la aplicación de Facturación DTE en un entorno de producción.

## Opción 1: Render.com (Recomendado para inicio rápido)

Render es una plataforma PaaS que facilita el despliegue de aplicaciones web y bases de datos.

### Prerrequisitos

- Cuenta en [Render.com](https://render.com).
- Código fuente subido a un repositorio de GitHub/GitLab.

### Pasos

1. **Crear Base de Datos PostgreSQL**:
   - En el dashboard de Render, crea un nuevo "PostgreSQL".
   - Nombre: `dte-db` (o el que prefieras).
   - Copia la `Internal Connection URL` (para uso interno) o `External Connection URL` (si necesitas acceder desde fuera).

2. **Crear Web Service**:
   - Crea un nuevo "Web Service" conectado a tu repositorio.
   - **Runtime**: Python 3.
   - **Build Command**: `pip install -r requirements.txt`.
   - **Start Command**: `gunicorn --config gunicorn_conf.py src.main:app`.
   - **Environment Variables**:
     - `PYTHON_VERSION`: `3.11.0`
     - `DATABASE_URL`: Pega la URL de conexión de tu base de datos creada en el paso 1.
     - `MH_NIT`: Tu NIT.
     - `MH_API_KEY`: Tu contraseña de API del MH.
     - `MH_PRIVATE_KEY_PASSWORD`: Contraseña de tu llave privada.
     - `ENCRYPTION_KEY`: Genera una clave segura (puedes usar `python -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())"`).

3. **Archivos de Certificados**:
   - Render no permite subir archivos directamente de forma sencilla en el plan gratuito.
   - **Opción A (Recomendada)**: Codificar los archivos `.p12` y `.pem` en base64 y guardarlos como variables de entorno (`MH_PRIVATE_KEY_BASE64`, `MH_PUBLIC_KEY_BASE64`), luego decodificarlos en el código al iniciar.
   - **Opción B**: Usar un "Disk" (requiere plan de pago) para almacenar los certificados.

## Opción 2: Docker / VPS (Ubuntu/Debian)

Para un control total, puedes usar un servidor virtual (VPS) con Docker.

### Prerrequisitos

- Servidor con Docker y Docker Compose instalados.
- Dominio apuntando a la IP del servidor.

### Pasos

1. **Clonar el Repositorio**:

   ```bash
   git clone <tu-repo-url>
   cd facturacion
   ```

2. **Configurar Entorno**:
   - Copia el archivo de ejemplo: `cp .env.example .env`
   - Edita `.env` con tus credenciales de producción.

3. **Certificados**:
   - Asegúrate de que tus archivos de certificado (`private_key.p12`, `public_key.pem`) estén en la carpeta `certs/` (o la ruta que hayas definido en `.env`).

4. **Desplegar**:

   ```bash
   docker compose up -d --build
   ```

5. **Migraciones de Base de Datos**:
   - Ejecuta las migraciones para crear las tablas:

   ```bash
   docker compose exec web alembic upgrade head
   ```

6. **Verificación**:
   - La API estará disponible en el puerto 8000.
   - Se recomienda configurar Nginx como proxy inverso para manejar SSL (HTTPS) y redirigir el tráfico del puerto 80 al 8000.

## Notas Importantes

- **CORS**: Se ha configurado `src/main.py` para permitir todos los orígenes (`*`). Para mayor seguridad, edita la lista `allow_origins` con tu dominio real (ej: `["https://mi-facturacion.com"]`).
- **Seguridad**: Nunca subas tus archivos de certificados o claves privadas al repositorio de código.

7. **Reiniciar**:
   - Haz clic en **"Restart"** en la aplicación de Python.
   - Visita tu URL. Deberías ver la aplicación funcionando.
